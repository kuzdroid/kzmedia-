// server.js
const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

// Public klasörünü ayarla (ön yüz dosyaları buradan gelir)
app.use(express.static(path.join(__dirname, "public")));

// Örnek API (post paylaşma için ileride buraya ekleriz)
app.get("/api/hello", (req, res) => {
  res.json({ message: "KZMedia API Çalışıyor 🚀" });
});

// Ana sayfa (index.html'i gönder)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Sunucuyu başlat
app.listen(PORT, () => {
  console.log(`KZMedia ${PORT} portunda çalışıyor`);
});

