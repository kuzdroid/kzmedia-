const KZUsers = ['kursatomer','elalye','sena k.'];
const userDB = { kursatomer:'KUZİLER', elalye:'KUZİLER', 'sena k.':'KUZİLER' };
let state={user:null};

// Otomatik giriş
window.addEventListener('load',()=>{
  const remember=localStorage.getItem('KZMedia.remember');
  if(remember){
    const isMember = KZUsers.includes(remember);
    state.user={name:remember,member:isMember};
    showMediaPanel();
  }
});

// Giriş
document.getElementById('loginBtn').addEventListener('click',()=>{
  const u=document.getElementById('loginUser').value.trim();
  const p=document.getElementById('loginPass').value;
  if(!u){alert('Kullanıcı adı gir!'); return;}
  if(userDB[u] && userDB[u]===p){ state.user={name:u,member:true}; }
  else{ state.user={name:u,member:false}; }
  const rem=document.getElementById('rememberMe').checked;
  if(rem) localStorage.setItem('KZMedia.remember',u);
  else localStorage.removeItem('KZMedia.remember');
  showMediaPanel();
});

function showMediaPanel(){
  document.getElementById('loginPanel').style.display='none';
  document.getElementById('mediaPanel').style.display='block';
  document.getElementById('currentUser').textContent=state.user.name;
  document.getElementById('memberTag').textContent=state.user.member?'@KUZİLER':'';
  loadFeed();
}

// Gönderi paylaş
document.getElementById('postBtn').addEventListener('click', async ()=>{
  const text=document.getElementById('postText').value.trim();
  if(!text) return alert('Metin boş olamaz!');
  const post = {
    author: state.user.name,
    text,
    imageUrl: document.getElementById('postImage').value.trim(),
    videoUrl: document.getElementById('postVideo').value.trim(),
    privateTag: document.getElementById('privateTag').checked
  };
  await fetch('/api/posts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(post)});
  document.getElementById('postText').value='';
  document.getElementById('postImage').value='';
  document.getElementById('postVideo').value='';
  document.getElementById('privateTag').checked=false;
  loadFeed();
});

// Feed yükle
async function loadFeed(){
  const res=await fetch('/api/posts');
  const posts=await res.json();
  const feed = document.getElementById('feed'); feed.innerHTML='';
  posts.slice().reverse().forEach(p=>{
    if(p.privateTag && !state.user.member) return;
    const div=document.createElement('div'); div.className='post card';
    let tag=p.member?' <span>@KUZİLER</span>':'';
    div.innerHTML=`<strong>${p.author}</strong>${tag}<p>${p.text}</p>
      ${p.imageUrl?`<img src="${p.imageUrl}">`:''}
      ${p.videoUrl?`<video controls src="${p.videoUrl}"></video>`:''}`;
    feed.appendChild(div);
  });
}
